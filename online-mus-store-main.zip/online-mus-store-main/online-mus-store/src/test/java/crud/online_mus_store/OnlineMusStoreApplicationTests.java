package crud.online_mus_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMusStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
