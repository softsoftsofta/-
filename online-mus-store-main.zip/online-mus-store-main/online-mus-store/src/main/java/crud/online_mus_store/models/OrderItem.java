package crud.online_mus_store.models;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * Класс, представляющий позицию в заказе (товар с количеством и ценой).
 */
@Entity
@Table(name = "Order-items")
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderItemId;

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    private int quantity;
    private BigDecimal price;

    /**
     * Возвращает идентификатор позиции заказа.
     * @return идентификатор позиции
     */
    public int getOrderItemId() {
        return orderItemId;
    }

    /**
     * Устанавливает идентификатор позиции заказа.
     * @param orderItemId идентификатор позиции
     */
    public void setOrderItemId(int orderItemId) {
        this.orderItemId = orderItemId;
    }

    /**
     * Возвращает заказ, к которому относится позиция.
     * @return объект заказа
     */
    public Order getOrder() {
        return order;
    }

    /**
     * Устанавливает заказ для позиции.
     * @param order объект заказа
     */
    public void setOrder(Order order) {
        this.order = order;
    }

    /**
     * Возвращает товар в позиции заказа.
     * @return объект товара
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Устанавливает товар для позиции заказа.
     * @param product объект товара
     */
    public void setProduct(Product product) {
        this.product = product;
    }

    /**
     * Возвращает количество товара в позиции.
     * @return количество товара
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Устанавливает количество товара в позиции.
     * @param quantity количество товара
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Возвращает цену товара в позиции.
     * @return цена товара
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Устанавливает цену товара в позиции.
     * @param price цена товара
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}