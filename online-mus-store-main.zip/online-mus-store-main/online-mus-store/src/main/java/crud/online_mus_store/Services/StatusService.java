package crud.online_mus_store.Services;

import crud.online_mus_store.models.Status;
import crud.online_mus_store.repos.StatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервис для работы со статусами заказов.
 * Обеспечивает бизнес-логику работы со статусами.
 */
@Service
public class StatusService {

    @Autowired
    private StatusRepository statusRepository;

    /**
     * Получает список всех статусов.
     * @return список статусов
     */
    public List<Status> getAllStatuses() {
        return statusRepository.findAll();
    }
}