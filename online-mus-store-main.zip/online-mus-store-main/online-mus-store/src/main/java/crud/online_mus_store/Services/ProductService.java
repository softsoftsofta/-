package crud.online_mus_store.Services;

import crud.online_mus_store.models.Product;
import crud.online_mus_store.repos.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервис для работы с товарами.
 * Обеспечивает бизнес-логику работы с товарами.
 */
@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    /**
     * Получает список всех товаров.
     * @return список товаров
     */
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Находит товар по идентификатору.
     * @param id идентификатор товара
     * @return найденный товар или null, если не найден
     */
    public Product getProductById(int id) {
        return productRepository.findById(id).orElse(null);
    }

    /**
     * Сохраняет или обновляет товар.
     * @param product объект товара для сохранения
     * @return сохраненный товар
     */
    public Product saveOrUpdateProduct(Product product) {
        return productRepository.save(product);
    }

    /**
     * Удаляет товар по идентификатору.
     * @param id идентификатор товара для удаления
     */
    public void deleteProduct(int id) {
        productRepository.deleteById(id);
    }
}