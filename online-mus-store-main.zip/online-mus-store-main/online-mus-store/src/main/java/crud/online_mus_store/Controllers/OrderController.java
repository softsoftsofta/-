package crud.online_mus_store.Controllers;

import crud.online_mus_store.Services.*;
import crud.online_mus_store.models.Order;
import crud.online_mus_store.models.OrderItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Контроллер для работы с заказами.
 * Обрабатывает HTTP-запросы, связанные с заказами.
 */
@Controller
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderItemService orderItemService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private StatusService statusService;

    /**
     * Отображает список всех заказов.
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения списка заказов
     */
    @GetMapping
    public String getAllOrders(Model model) {
        model.addAttribute("orders", orderService.getAllOrders());
        return "orders";
    }

    /**
     * Отображает форму для создания нового заказа.
     * @param model модель для передачи данных в представление
     * @return имя представления формы заказа
     */
    @GetMapping("/new")
    public String showOrderForm(Model model) {
        model.addAttribute("order", new Order());
        model.addAttribute("customers", customerService.getAllCustomers());
        model.addAttribute("statuses", statusService.getAllStatuses());
        return "order-form";
    }

    /**
     * Сохраняет новый или обновляет существующий заказ.
     * @param order объект заказа из формы
     * @return перенаправление на список заказов
     */
    @PostMapping("/save")
    public String saveOrder(@ModelAttribute Order order) {
        orderService.saveOrUpdateOrder(order);
        return "redirect:/orders";
    }

    /**
     * Отображает форму для редактирования заказа.
     * @param id идентификатор заказа для редактирования
     * @param model модель для передачи данных в представление
     * @return имя представления формы заказа
     */
    @GetMapping("/edit/{id}")
    public String editOrder(@PathVariable int id, Model model) {
        model.addAttribute("order", orderService.getOrderById(id));
        model.addAttribute("customers", customerService.getAllCustomers());
        model.addAttribute("statuses", statusService.getAllStatuses());
        return "order-form";
    }

    /**
     * Удаляет заказ по идентификатору.
     * @param id идентификатор заказа для удаления
     * @return перенаправление на список заказов
     */
    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable int id) {
        orderService.deleteOrder(id);
        return "redirect:/orders";
    }

    /**
     * Отображает список позиций для конкретного заказа.
     * @param orderId идентификатор заказа
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения позиций заказа
     */
    @GetMapping("/{orderId}/order-items")
    public String getOrderItemsForOrder(@PathVariable int orderId, Model model) {
        List<OrderItem> orderItems = orderItemService.getOrderItemsByOrderId(orderId);
        model.addAttribute("orderItems", orderItems);
        model.addAttribute("orderId", orderId);
        return "order-items-for-order";
    }
}