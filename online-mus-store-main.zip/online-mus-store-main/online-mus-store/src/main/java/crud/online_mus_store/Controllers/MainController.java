package crud.online_mus_store.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Главный контроллер приложения.
 * Обрабатывает запросы к корневому пути приложения.
 */
@Controller
public class MainController {

    /**
     * Отображает главную страницу приложения.
     * @return имя представления главной страницы
     */
    @GetMapping("/")
    public String showMainPage() {
        return "Index"; // Serve the index.html template
    }
}