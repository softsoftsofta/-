package crud.online_mus_store.Controllers;

import crud.online_mus_store.Services.CustomerService;
import crud.online_mus_store.models.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Контроллер для работы с покупателями.
 * Обрабатывает HTTP-запросы, связанные с покупателями.
 */
@Controller
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    /**
     * Отображает список всех покупателей.
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения списка покупателей
     */
    @GetMapping
    public String getAllCustomers(Model model) {
        model.addAttribute("customers", customerService.getAllCustomers());
        return "customers";
    }

    /**
     * Отображает форму для создания нового покупателя.
     * @param model модель для передачи данных в представление
     * @return имя представления формы покупателя
     */
    @GetMapping("/new")
    public String showCustomerForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "customer-form";
    }

    /**
     * Сохраняет нового или обновляет существующего покупателя.
     * @param customer объект покупателя из формы
     * @return перенаправление на список покупателей
     */
    @PostMapping("/save")
    public String saveCustomer(@ModelAttribute Customer customer) {
        customerService.saveOrUpdateCustomer(customer);
        return "redirect:/customers";
    }

    /**
     * Отображает форму для редактирования покупателя.
     * @param id идентификатор покупателя для редактирования
     * @param model модель для передачи данных в представление
     * @return имя представления формы покупателя
     */
    @GetMapping("/edit/{id}")
    public String editCustomer(@PathVariable int id, Model model) {
        model.addAttribute("customer", customerService.getCustomerById(id));
        return "customer-form";
    }

    /**
     * Удаляет покупателя по идентификатору.
     * @param id идентификатор покупателя для удаления
     * @return перенаправление на список покупателей
     */
    @GetMapping("/delete/{id}")
    public String deleteCustomer(@PathVariable int id) {
        customerService.deleteCustomer(id);
        return "redirect:/customers";
    }
}