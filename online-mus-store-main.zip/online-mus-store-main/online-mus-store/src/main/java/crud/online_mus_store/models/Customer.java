package crud.online_mus_store.models;

import jakarta.persistence.*;

/**
 * Класс, представляющий покупателя музыкального магазина.
 */
@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int customerId;

    private String firstName;
    private String lastName;
    private String email;
    private String phone;

    /**
     * Возвращает идентификатор покупателя.
     * @return идентификатор покупателя
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Устанавливает идентификатор покупателя.
     * @param customerId идентификатор покупателя
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Возвращает имя покупателя.
     * @return имя покупателя
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Устанавливает имя покупателя.
     * @param firstName имя покупателя
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Возвращает фамилию покупателя.
     * @return фамилия покупателя
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Устанавливает фамилию покупателя.
     * @param lastName фамилия покупателя
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Возвращает email покупателя.
     * @return email покупателя
     */
    public String getEmail() {
        return email;
    }

    /**
     * Устанавливает email покупателя.
     * @param email email покупателя
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Возвращает телефон покупателя.
     * @return телефон покупателя
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Устанавливает телефон покупателя.
     * @param phone телефон покупателя
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }
}