package crud.online_mus_store.models;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * Класс, представляющий товар в музыкальном магазине.
 */
@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int productId;

    private String name;
    private String description;
    private BigDecimal price;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    /**
     * Возвращает идентификатор товара.
     * @return идентификатор товара
     */
    public int getProductId() {
        return productId;
    }

    /**
     * Устанавливает идентификатор товара.
     * @param productId идентификатор товара
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * Возвращает название товара.
     * @return название товара
     */
    public String getName() {
        return name;
    }

    /**
     * Устанавливает название товара.
     * @param name название товара
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Возвращает описание товара.
     * @return описание товара
     */
    public String getDescription() {
        return description;
    }

    /**
     * Устанавливает описание товара.
     * @param description описание товара
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Возвращает цену товара.
     * @return цена товара
     */
    public BigDecimal getPrice() {
        return price;
    }

    /**
     * Устанавливает цену товара.
     * @param price цена товара
     */
    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    /**
     * Возвращает категорию товара.
     * @return объект категории
     */
    public Category getCategory() {
        return category;
    }

    /**
     * Устанавливает категорию для товара.
     * @param category объект категории
     */
    public void setCategory(Category category) {
        this.category = category;
    }
}