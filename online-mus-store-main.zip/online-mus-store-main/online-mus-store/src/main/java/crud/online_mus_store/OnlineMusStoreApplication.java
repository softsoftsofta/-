package crud.online_mus_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMusStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMusStoreApplication.class, args);
	}

}
