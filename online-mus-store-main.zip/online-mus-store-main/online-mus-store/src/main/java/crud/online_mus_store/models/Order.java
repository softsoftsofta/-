package crud.online_mus_store.models;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Класс, представляющий заказ в музыкальном магазине.
 */
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    private LocalDateTime orderDate;

    @ManyToOne
    @JoinColumn(name = "statusId", nullable = false)
    private Status status;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    /**
     * Возвращает идентификатор заказа.
     * @return идентификатор заказа
     */
    public int getOrderId() {
        return orderId;
    }

    /**
     * Устанавливает идентификатор заказа.
     * @param orderId идентификатор заказа
     */
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    /**
     * Возвращает покупателя, сделавшего заказ.
     * @return объект покупателя
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Устанавливает покупателя для заказа.
     * @param customer объект покупателя
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * Возвращает дату и время оформления заказа.
     * @return дата и время заказа
     */
    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    /**
     * Устанавливает дату и время оформления заказа.
     * @param orderDate дата и время заказа
     */
    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    /**
     * Возвращает статус заказа.
     * @return объект статуса
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Устанавливает статус заказа.
     * @param status объект статуса
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Возвращает общую сумму заказа.
     * @return общая сумма
     */
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    /**
     * Устанавливает общую сумму заказа.
     * @param totalAmount общая сумма
     */
    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}