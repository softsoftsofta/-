package crud.online_mus_store.models;

import jakarta.persistence.*;

/**
 * Класс, представляющий статус заказа.
 */
@Entity
public class Status {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int status_id;

    private String statusName;

    /**
     * Возвращает идентификатор статуса.
     * @return идентификатор статуса
     */
    public int getStatusId() {
        return status_id;
    }

    /**
     * Устанавливает идентификатор статуса.
     * @param statusId идентификатор статуса
     */
    public void setStatusId(int statusId) {
        this.status_id = statusId;
    }

    /**
     * Возвращает название статуса.
     * @return название статуса
     */
    public String getStatusName() {
        return statusName;
    }

    /**
     * Устанавливает название статуса.
     * @param statusName название статуса
     */
    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }
}