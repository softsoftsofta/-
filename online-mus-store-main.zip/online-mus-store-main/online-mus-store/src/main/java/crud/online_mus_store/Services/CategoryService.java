package crud.online_mus_store.Services;

import crud.online_mus_store.models.Category;
import crud.online_mus_store.repos.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Сервис для работы с категориями товаров.
 * Обеспечивает бизнес-логику работы с категориями.
 */
@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    /**
     * Получает список всех категорий.
     * @return список категорий
     */
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    /**
     * Находит категорию по идентификатору.
     * @param id идентификатор категории
     * @return найденная категория или null, если не найдена
     */
    public Category getCategoryById(int id) {
        return categoryRepository.findById(id).orElse(null);
    }

    /**
     * Сохраняет или обновляет категорию.
     * @param category объект категории для сохранения
     * @return сохраненная категория
     */
    public Category saveOrUpdateCategory(Category category) {
        return categoryRepository.save(category);
    }

    /**
     * Удаляет категорию по идентификатору.
     * @param id идентификатор категории для удаления
     */
    public void deleteCategory(int id) {
        categoryRepository.deleteById(id);
    }
}