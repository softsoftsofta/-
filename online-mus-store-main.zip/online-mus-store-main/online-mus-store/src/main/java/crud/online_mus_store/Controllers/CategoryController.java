package crud.online_mus_store.Controllers;

import crud.online_mus_store.Services.CategoryService;
import crud.online_mus_store.models.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Контроллер для работы с категориями товаров.
 * Обрабатывает HTTP-запросы, связанные с категориями.
 */
@Controller
@RequestMapping("/categories")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    /**
     * Отображает список всех категорий.
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения списка категорий
     */
    @GetMapping
    public String getAllCategories(Model model) {
        model.addAttribute("categories", categoryService.getAllCategories());
        return "categories";
    }

    /**
     * Отображает форму для создания новой категории.
     * @param model модель для передачи данных в представление
     * @return имя представления формы категории
     */
    @GetMapping("/new")
    public String showCategoryForm(Model model) {
        model.addAttribute("category", new Category());
        return "category-form";
    }

    /**
     * Сохраняет новую или обновляет существующую категорию.
     * @param category объект категории из формы
     * @return перенаправление на список категорий
     */
    @PostMapping("/save")
    public String saveCategory(@ModelAttribute Category category) {
        categoryService.saveOrUpdateCategory(category);
        return "redirect:/categories";
    }

    /**
     * Отображает форму для редактирования категории.
     * @param id идентификатор категории для редактирования
     * @param model модель для передачи данных в представление
     * @return имя представления формы категории
     */
    @GetMapping("/edit/{id}")
    public String editCategory(@PathVariable int id, Model model) {
        model.addAttribute("category", categoryService.getCategoryById(id));
        return "category-form";
    }

    /**
     * Удаляет категорию по идентификатору.
     * @param id идентификатор категории для удаления
     * @return перенаправление на список категорий
     */
    @GetMapping("/delete/{id}")
    public String deleteCategory(@PathVariable int id) {
        categoryService.deleteCategory(id);
        return "redirect:/categories";
    }
}