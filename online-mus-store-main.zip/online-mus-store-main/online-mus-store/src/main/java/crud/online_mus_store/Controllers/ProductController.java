package crud.online_mus_store.Controllers;

import crud.online_mus_store.Services.CategoryService;
import crud.online_mus_store.Services.ProductService;
import crud.online_mus_store.models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

/**
 * Контроллер для работы с товарами.
 * Обрабатывает HTTP-запросы, связанные с товарами.
 */
@Controller
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    /**
     * Отображает список всех товаров.
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения списка товаров
     */
    @GetMapping
    public String getAllProducts(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "products";
    }

    /**
     * Отображает форму для создания нового товара.
     * @param model модель для передачи данных в представление
     * @return имя представления формы товара
     */
    @GetMapping("/new")
    public String showProductForm(Model model) {
        model.addAttribute("product", new Product());
        model.addAttribute("categories", categoryService.getAllCategories());
        return "product-form";
    }

    /**
     * Сохраняет новый или обновляет существующий товар.
     * @param product объект товара из формы
     * @return перенаправление на список товаров
     */
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute Product product) {
        productService.saveOrUpdateProduct(product);
        return "redirect:/products";
    }

    /**
     * Отображает форму для редактирования товара.
     * @param id идентификатор товара для редактирования
     * @param model модель для передачи данных в представление
     * @return имя представления формы товара
     */
    @GetMapping("/edit/{id}")
    public String editProduct(@PathVariable int id, Model model) {
        model.addAttribute("product", productService.getProductById(id));
        model.addAttribute("categories", categoryService.getAllCategories());
        return "product-form";
    }

    /**
     * Удаляет товар по идентификатору.
     * @param id идентификатор товара для удаления
     * @return перенаправление на список товаров
     */
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable int id) {
        productService.deleteProduct(id);
        return "redirect:/products";
    }
}