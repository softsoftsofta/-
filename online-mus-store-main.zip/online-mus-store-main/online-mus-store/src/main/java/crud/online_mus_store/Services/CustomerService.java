package crud.online_mus_store.Services;

import crud.online_mus_store.models.Customer;
import crud.online_mus_store.repos.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Сервис для работы с покупателями.
 * Обеспечивает бизнес-логику работы с покупателями.
 */
@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    /**
     * Получает список всех покупателей.
     * @return список покупателей
     */
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    /**
     * Находит покупателя по идентификатору.
     * @param id идентификатор покупателя
     * @return найденный покупатель или null, если не найден
     */
    public Customer getCustomerById(int id) {
        return customerRepository.findById(id).orElse(null);
    }

    /**
     * Сохраняет или обновляет данные покупателя.
     * @param customer объект покупателя для сохранения
     * @return сохраненный покупатель
     */
    public Customer saveOrUpdateCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    /**
     * Удаляет покупателя по идентификатору.
     * @param id идентификатор покупателя для удаления
     */
    public void deleteCustomer(int id) {
        customerRepository.deleteById(id);
    }
}