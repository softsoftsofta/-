package crud.online_mus_store.repos;

import crud.online_mus_store.models.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Репозиторий для работы с позициями заказов.
 */
public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {
    /**
     * Находит все позиции заказа по идентификатору заказа.
     * @param orderId идентификатор заказа
     */
    List<OrderItem> findByOrderOrderId(int orderId);
}