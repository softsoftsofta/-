package crud.online_mus_store.models;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Класс, представляющий категорию товаров в музыкальном магазине.
 * Категории могут иметь иерархическую структуру через parentId.
 */
@Entity
@Table(name = "categories")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int categoryId;

    private String categoryName;
    private String description;
    private Integer parentId;
    private LocalDateTime createdAt;

    /**
     * Возвращает идентификатор категории.
     * @return идентификатор категории
     */
    public int getCategoryId() {
        return categoryId;
    }

    /**
     * Устанавливает идентификатор категории.
     * @param categoryId идентификатор категории
     */
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * Возвращает название категории.
     * @return название категории
     */
    public String getCategoryName() {
        return categoryName;
    }

    /**
     * Устанавливает название категории.
     * @param categoryName название категории
     */
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    /**
     * Возвращает описание категории.
     * @return описание категории
     */
    public String getDescription() {
        return description;
    }

    /**
     * Устанавливает описание категории.
     * @param description описание категории
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Возвращает идентификатор родительской категории.
     * @return идентификатор родительской категории (может быть null)
     */
    public Integer getParentId() {
        return parentId;
    }

    /**
     * Устанавливает идентификатор родительской категории.
     * @param parentId идентификатор родительской категории
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    /**
     * Возвращает дату и время создания категории.
     * @return дата и время создания
     */
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Устанавливает дату и время создания категории.
     * @param createdAt дата и время создания
     */
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}