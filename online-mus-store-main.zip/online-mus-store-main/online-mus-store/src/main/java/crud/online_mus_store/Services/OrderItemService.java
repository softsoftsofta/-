package crud.online_mus_store.Services;

import crud.online_mus_store.models.OrderItem;
import crud.online_mus_store.repos.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Сервис для работы с позициями заказов.
 * Обеспечивает бизнес-логику работы с позициями заказов.
 */
@Service
public class OrderItemService {
    @Autowired
    private OrderItemRepository orderItemRepository;

    /**
     * Получает список всех позиций заказов.
     * @return список позиций заказов
     */
    public List<OrderItem> getAllOrderItems() {
        return orderItemRepository.findAll();
    }

    /**
     * Находит позицию заказа по идентификатору.
     * @param id идентификатор позиции заказа
     * @return найденная позиция или null, если не найдена
     */
    public OrderItem getOrderItemById(int id) {
        return orderItemRepository.findById(id).orElse(null);
    }

    /**
     * Сохраняет или обновляет позицию заказа.
     * @param orderItem объект позиции заказа для сохранения
     * @return сохраненная позиция заказа
     */
    public OrderItem saveOrUpdateOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    /**
     * Удаляет позицию заказа по идентификатору.
     * @param id идентификатор позиции заказа для удаления
     */
    public void deleteOrderItem(int id) {
        orderItemRepository.deleteById(id);
    }

    /**
     * Получает все позиции заказа по идентификатору заказа.
     * @param orderId идентификатор заказа
     * @return список позиций заказа
     */
    public List<OrderItem> getOrderItemsByOrderId(int orderId) {
        return orderItemRepository.findByOrderOrderId(orderId);
    }
}